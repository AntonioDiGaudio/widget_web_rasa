const action_name = "action_hello_world";
const rasa_server_url = "https://widget.travelino.chat/webhooks/rest/webhook/";
const sender_id = uuidv4();